import nltk
import ssl

# use this code to download the pre trained word tokenizer
# we had and issue of ssl using nltk.download() so we used the below code to fix the same
# one we download this data we no longer require it to redownload

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

nltk.download('punkt')