## Doc Booking Assistant / Bot

## TODO
1. Training The Model
2. Building Backend On Top Of It
3. Building Mobile Application
