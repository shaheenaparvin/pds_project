//
//  ContentView.swift
//  doc_chat
//
//  Created by Venkat Manavarthi on 4/28/24.
//

import SwiftUI

struct ContentView: View {
    @State var messages: [Message] = []
    @State var message = ""
    @FocusState var isTypingMessage: Bool
    var networkManager = NetworkManager()
    
    var body: some View {
        NavigationStack{
            VStack{
                List{
                    ForEach(messages, id: \.id) { message in
                        DirectMessageView(message: message)
                    }
                }
                .listStyle(.insetGrouped)
                HStack {
                    TextField("Enter message", text: $message)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .focused($isTypingMessage)
                    
                    Button(action: {
                        isTypingMessage = false
                        Task{
                            await self.sendMessage(message: message)
                        }
                    }) {
                        Image(systemName: "paperplane")
                            .padding(.trailing)
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Doc Chat")
        }
    }
    
    
    func sendMessage(message: String) async {
        let msg = Message(message: message, type: "Direct", via: "You")
        self.messages.append(msg)
        let data = await networkManager.post(url: Constant.sendMessage, data: msg)
        self.messages.append(Message(message: data?.message ?? "", type: data?.type ?? "", via: "Bot"))
        self.message.removeAll()
    }
}

#Preview {
    ContentView()
}
