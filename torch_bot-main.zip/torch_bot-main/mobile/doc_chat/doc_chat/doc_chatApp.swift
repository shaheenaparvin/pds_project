//
//  doc_chatApp.swift
//  doc_chat
//
//  Created by Venkat Manavarthi on 4/28/24.
//

import SwiftUI

@main
struct doc_chatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
