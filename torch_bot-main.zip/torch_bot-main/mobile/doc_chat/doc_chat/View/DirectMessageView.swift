//
//  DirectMessageView.swift
//  doc_chat
//
//  Created by Venkat Manavarthi on 4/28/24.
//

import SwiftUI

struct DirectMessageView: View {
    let message: Message
    var body: some View {
        VStack(alignment: .leading){
            Text(message.via)
            Text(message.message ?? "")
                .padding(.trailing)
                .padding(.leading)
                .padding(.bottom)
                .presentationCornerRadius(10)
        }
    }
}

#Preview (traits: .sizeThatFitsLayout){
    DirectMessageView(message: Message(message: "Hi, How are you", type: "Direct", via: "Doc Bot"))
}

