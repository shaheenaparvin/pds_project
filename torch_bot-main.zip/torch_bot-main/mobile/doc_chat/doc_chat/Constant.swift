//
//  Constant.swift
//  doc_chat
//
//  Created by Venkat Manavarthi on 4/28/24.
//

import Foundation
struct Constant {
    static let BASE_URL = "http://127.0.0.1:8000/"
    static let sendMessage = "\(BASE_URL)send"
}
